-- Adminer 4.5.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DELIMITER ;;

DROP PROCEDURE IF EXISTS `dorepeat`;;
CREATE PROCEDURE `dorepeat`(p1 INT)
BEGIN
    SET @x = 0;
    REPEAT SET @x = @x + 1; UNTIL @x > p1 END REPEAT;
  END;;

DROP PROCEDURE IF EXISTS `getCards`;;
CREATE PROCEDURE `getCards`()
BEGIN

    DECLARE columnNames VARCHAR(128);
    SET @SQL = "SELECT COLUMN_NAME FROM information_schema.COLUMNS  
                      WHERE TABLE_SCHEMA = 'PumDB' AND TABLE_NAME = 'Card' AND COLUMN_NAME <> 'ID'";
    
    PREPARE stmt FROM @SQL;
    EXECUTE stmt;
  END;;

DELIMITER ;

DROP TABLE IF EXISTS `LogType`;
CREATE TABLE `LogType` (
  `ID` int(32) NOT NULL AUTO_INCREMENT,
  `Name` varchar(32) NOT NULL,
  `LogText` varchar(256) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `LogType` (`ID`, `Name`, `LogText`) VALUES
(1,	'Inkvittering',	'Inkvittering av $data'),
(2,	'Utkvittering',	'Utkvittering av $data'),
(3,	'Skapat',	'$data skapades'),
(4,	'Ändring',	'$data ändrades'),
(5,	'Status',	'Ändrade status på $data'),
(6,	'Inventering',	'$data inventerades'),
(7,	'Egenkontroll',	'Egenkontroll av $data utfördes');

-- 2018-05-22 17:02:18
